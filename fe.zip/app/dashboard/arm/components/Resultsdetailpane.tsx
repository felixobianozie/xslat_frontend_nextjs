"use client";

// ─────────────────────────────────────────────────────────────────────────────
// ResultsDetailPane.tsx
//
// Right pane of the master-detail layout. Renders, in order:
//   1. Back link (mobile only — slides back to master list)
//   2. Term header
//   3. Prev / Next student navigation
//   4. Selected student's full name
//   5. Summary stats card (class avg, student avg, position, decision)
//   6. The active filter's content view
//
// Phase 1 implements only the ACADEMICS view. The other three filters (BEHAVIOURS,
// SKILLS, GENERAL) render a clearly-labelled placeholder so the navigation is
// usable while Phase 2 fills them in.
// ─────────────────────────────────────────────────────────────────────────────

import { ChevronLeft, ChevronRight } from "lucide-react";
import { useArmDetails } from "../context/Armdetailsprovider";
import TableLoader from "../../components/Tableloader";
import ResultsAcademicsView from "./Resultsacademicsview";
import ResultsTraitsGridView from "./Resultstraitsgridview";
import ResultsGeneralView from "./Resultsgeneralview";
import { ResultsFilterKey } from "./Resultsfilter";

interface ResultsDetailPaneProps {
  student: ArmStudent;
  // All students in the arm — used to derive the Prev/Next neighbours.
  allStudents: ArmStudent[];
  // Computed assessment data for the entire class.
  classResult: ClassAssessmentResult;
  // Currently active filter view.
  filter: ResultsFilterKey;
  // True while the class-assessment-compute query is still pending. Combined
  // with the arm-detail pending flag (read from context) to decide whether
  // the filter-specific view below the summary card should render a loader
  // instead of the child view's "not configured" / "no records" empty state.
  classResultLoading: boolean;
  // Mobile back action — caller controls whether to show the back link.
  onBack: () => void;
  // Prev / Next selection — caller decides which student becomes active.
  onSelect: (next: ArmStudent) => void;
}

function fullName(s: ArmStudent): string {
  return `${s.last_name} ${s.first_name} ${s.middle_name ? ` ${s.middle_name}` : ""}`;
}

export default function ResultsDetailPane({
  student,
  allStudents,
  classResult,
  filter,
  classResultLoading,
  onBack,
  onSelect,
}: ResultsDetailPaneProps) {
  const { arm, isPending: armLoading } = useArmDetails();

  const studentResult = classResult.students[student.id];

  // Both the arm detail (which supplies assessment + grading formats) and the
  // compute payload (which supplies per-student scores) must be present before
  // the filter-specific views can distinguish "no data yet" from "not
  // configured". While either is loading we show a loader in place of the
  // child view so the user isn't briefly told the format is missing.
  const filterViewLoading = armLoading || classResultLoading;

  // Compute Prev / Next neighbours from the master list. Edges clamp.
  const currentIndex = allStudents.findIndex((s) => s.id === student.id);
  const hasPrev = currentIndex > 0;
  const hasNext = currentIndex >= 0 && currentIndex < allStudents.length - 1;

  function handlePrev() {
    if (hasPrev) onSelect(allStudents[currentIndex - 1]);
  }
  function handleNext() {
    if (hasNext) onSelect(allStudents[currentIndex + 1]);
  }

  const termName = arm?.level.section.term?.name ?? "Current Term";

  return (
    <div className="flex flex-col gap-5">
      {/* ── Back link — mobile only ─────────────────────────────────── */}
      <button
        type="button"
        onClick={onBack}
        className="md:hidden flex items-center gap-1 text-xs text-red-600 hover:text-red-700 transition-all hover:scale-105 w-fit cursor-pointer"
      >
        <ChevronLeft size={14} />
        <span>Back to list</span>
      </button>

      {/* ── Header strip: term + prev/next ──────────────────────────── */}
      <div className="flex items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div className="text-xs text-slate-500 uppercase tracking-wide">
          {termName} Term | Report
        </div>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={handlePrev}
            disabled={!hasPrev}
            className="flex items-center gap-1 px-2.5 py-1.5 text-[11px] border border-slate-200 rounded-lg bg-white text-slate-600 hover:border-violet-300 disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer"
          >
            <ChevronLeft size={11} />
            Prev
          </button>
          <span className="text-[10px] text-slate-400 tabular-nums px-1">
            {currentIndex >= 0 ? currentIndex + 1 : 0} / {allStudents.length}
          </span>
          <button
            type="button"
            onClick={handleNext}
            disabled={!hasNext}
            className="flex items-center gap-1 px-2.5 py-1.5 text-[11px] border border-slate-200 rounded-lg bg-white text-slate-600 hover:border-violet-300 disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer"
          >
            Next
            <ChevronRight size={11} />
          </button>
        </div>
      </div>

      {/* ── Student name ────────────────────────────────────────────── */}
      <div className="text-center md:text-left">
        <h2 className="text-lg md:text-xl font-bold text-slate-800">
          {fullName(student)}
        </h2>
        {student.public_id && (
          <p className="text-[11px] text-slate-400 font-mono mt-0.5">
            {student.public_id}
          </p>
        )}
      </div>

      {/* ── Summary stats card ──────────────────────────────────────── */}
      <SummaryCard
        classAverage={classResult.class_average}
        studentAverage={studentResult?.average}
        position={studentResult?.position}
        decision={studentResult?.decision}
        populationCount={classResult.student_population}
        gender={studentResult?.student_gender}
        totalScore={studentResult?.total_score}
        totalObtainable={studentResult?.total_score_obtainable}
        gradingSummary={studentResult?.grading_summary}
      />

      {/* ── Filter-specific view ──────────────────────────────────────
          While the arm-detail or compute query is still pending, render a
          loader instead of the actual view. Without this gate the child
          views can't tell the difference between "loading" and "genuinely
          unavailable", so they briefly flash empty states like "Cognitive
          format not configured" before the data lands. */}
      {filterViewLoading ? (
        <TableLoader rows={6} />
      ) : (
        <>
          {filter === "ACADEMICS" && (
            <ResultsAcademicsView
              student={student}
              studentResult={studentResult}
              units={arm?.cognitive_assessment_format?.units}
            />
          )}

          {filter === "BEHAVIOURS" && (
            <ResultsTraitsGridView
              kind="affective"
              student={student}
              traits={arm?.affective_assessment_format?.behaviours ?? []}
              gradingFormat={arm?.aff_grading_format}
              existingResults={studentResult?.behaviours ?? {}}
            />
          )}

          {filter === "SKILLS" && (
            <ResultsTraitsGridView
              kind="psychomotor"
              student={student}
              traits={arm?.psychomotor_assessment_format?.activities ?? []}
              gradingFormat={arm?.psy_grading_format}
              existingResults={studentResult?.skills ?? {}}
            />
          )}

          {filter === "GENERAL" && (
            <ResultsGeneralView
              student={student}
              studentResult={studentResult}
            />
          )}
        </>
      )}

      {/* ── Bottom prev/next nav ──────────────────────────────────────────
          Mirrors the action in the header strip but with a richer layout:
          each button shows the neighbour's name as a clear affordance, so
          the user can advance without scrolling back to the top after
          finishing the last section (typically the principal's comment in
          the General view). Hidden when there's only one student in the
          arm — nothing to navigate to. */}
      {allStudents.length > 1 && (
        <div className="flex items-stretch gap-2 border-t border-slate-200 pt-5">
          <button
            type="button"
            onClick={handlePrev}
            disabled={!hasPrev}
            className="flex-1 sm:flex-initial flex items-center gap-2.5 px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white text-slate-700 hover:border-violet-300 disabled:opacity-40 disabled:cursor-not-allowed transition-colors text-left min-w-0 cursor-pointer"
          >
            <ChevronLeft size={14} className="shrink-0 text-slate-500" />
            <span className="flex flex-col min-w-0">
              <span className="text-[9px] uppercase tracking-wide text-slate-400 font-semibold">
                Previous Student
              </span>
              <span className="truncate text-slate-700">
                {hasPrev ? fullName(allStudents[currentIndex - 1]) : "—"}
              </span>
            </span>
          </button>

          {/* Position indicator — hidden on mobile to keep the two buttons
              from squeezing each other. The header strip already shows it
              above, so this is just a convenient mid-line reference. */}
          <span className="hidden sm:flex self-center text-[11px] text-slate-400 tabular-nums px-2">
            {currentIndex + 1} / {allStudents.length}
          </span>

          <button
            type="button"
            onClick={handleNext}
            disabled={!hasNext}
            className="flex-1 sm:flex-initial flex items-center gap-2.5 px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white text-slate-700 hover:border-violet-300 disabled:opacity-40 disabled:cursor-not-allowed transition-colors text-right min-w-0 cursor-pointer"
          >
            {/* Column is right-pushed with ml-auto; children stretch to its
                width (default items-stretch, NOT items-end) so `truncate` on
                the name has a bounded parent and long names ellipsise
                cleanly instead of overflowing left of the button. */}
            <span className="flex flex-col min-w-0 ml-auto">
              <span className="text-right text-[9px] uppercase tracking-wide text-slate-400 font-semibold">
                Next Student
              </span>
              <span className="text-right truncate text-slate-700">
                {hasNext ? fullName(allStudents[currentIndex + 1]) : "—"}
              </span>
            </span>
            <ChevronRight size={14} className="shrink-0 text-slate-500" />
          </button>
        </div>
      )}
    </div>
  );
}

// ── Summary stats — class + student averages, position, decision ─────────────

interface SummaryCardProps {
  classAverage: number;
  studentAverage: number | undefined;
  position: number | undefined;
  decision: "Pass" | "Fail" | "—" | undefined;
  populationCount: number;
  // Student's gender code as returned by the backend. Typically "M", "F",
  // or "O" — expanded to Male/Female/Other in the UI. Any other value
  // (or null) renders as-is / "—".
  gender: string | null | undefined;
  // Student's raw aggregate score (sum of subject totals) and the max
  // achievable for that student given their subject enrolments. Rendered
  // together as "score / obtainable" — the same "value of context" style
  // as the Position stat. Both come from the compute payload.
  totalScore: number | undefined;
  totalObtainable: number | undefined;
  // Distribution of subject grade prefixes for this student — e.g.
  // { A: 3, B: 4, C: 2 }. The backend seeds every prefix from the arm's
  // grading format (so zero-count entries CAN appear in the map), but only
  // the bands the student actually earned (count > 0) render as pills;
  // zeros are filtered out below.
  gradingSummary: Record<string, number> | undefined;
}

function SummaryCard({
  classAverage,
  studentAverage,
  position,
  decision,
  populationCount,
  gender,
  totalScore,
  totalObtainable,
  gradingSummary,
}: SummaryCardProps) {
  // Grade distribution — only the bands the student actually earned.
  // Zero-count prefixes (e.g. F: 0 for a student who failed nothing) are
  // excluded so the strip focuses on real earnings. Alphabetical sort
  // keeps the order stable regardless of backend map iteration.
  const gradeEntries = gradingSummary
    ? Object.entries(gradingSummary)
        .filter(([, count]) => count > 0)
        .sort(([a], [b]) => a.localeCompare(b))
    : [];

  const hasGradingSummary = gradeEntries.length > 0;
  const hasTotal = totalScore !== undefined;

  return (
    <div className="flex flex-col gap-2.5">
      {/* Primary stat row — unchanged from the original layout. */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
        <Stat label="Class Average" value={classAverage.toFixed(2)} />
        <Stat
          label="Student Average"
          value={studentAverage !== undefined ? studentAverage.toFixed(2) : "—"}
        />
        <Stat
          label="Position"
          value={
            position !== undefined
              ? `${ordinal(position)} of ${populationCount}`
              : "—"
          }
        />
        <Stat
          label="Decision"
          value={decision ?? "—"}
          tone={
            decision === "Pass"
              ? "success"
              : decision === "Fail"
                ? "danger"
                : "neutral"
          }
        />
      </div>

      {/* Secondary row — gender + total + grade distribution. Hidden entirely
          when none of the three fields have data (e.g. student not in the
          compute payload). */}
      {(gender || hasTotal || hasGradingSummary) && (
        <div className="flex flex-col md:flex-row gap-2.5">
          {/* Gender + Total pair.
              Mobile: a 2-col grid so the two cards sit side by side,
              matching the Position / Decision rhythm in the primary row
              above. A lone card (when only one of the two is present)
              spans both columns via col-span-2 so it doesn't leave an
              empty cell.
              Desktop: `md:contents` dissolves this wrapper so Gender and
              Total become direct children of the outer flex row and keep
              their fixed 160px widths — desktop layout is unchanged. */}
          {(gender !== undefined || hasTotal) && (
            <div className="grid grid-cols-2 gap-2.5 md:contents">
              {gender !== undefined && (
                <Stat
                  label="Gender"
                  value={formatGender(gender)}
                  // Narrow on desktop so it doesn't fight the pills for width.
                  // Full width on mobile only when Total is absent — otherwise
                  // it shares the row with Total.
                  className={`md:w-40 md:shrink-0 ${
                    !hasTotal ? "col-span-2 md:col-span-1" : ""
                  }`}
                />
              )}
              {hasTotal && (
                <Stat
                  label="Total"
                  // Include the obtainable when the backend provides it — the
                  // "score / max" format mirrors how Position surfaces its
                  // denominator context. Fall back to just the score if the
                  // obtainable is missing so the card never renders "n / undefined".
                  value={
                    totalObtainable !== undefined
                      ? `${totalScore} / ${totalObtainable}`
                      : String(totalScore)
                  }
                  className={`md:w-40 md:shrink-0 ${
                    gender === undefined ? "col-span-2 md:col-span-1" : ""
                  }`}
                />
              )}
            </div>
          )}
          {hasGradingSummary && (
            <div className="flex-1 border border-slate-200 rounded-xl bg-white px-3 py-2.5">
              <div className="text-[10px] uppercase tracking-wide text-slate-400 font-semibold">
                Grade Summary
              </div>
              <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                {gradeEntries.map(([symbol, count]) => (
                  <span
                    key={symbol}
                    className="inline-flex items-center gap-1 px-2 py-0.5 text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-200 rounded-md"
                  >
                    <span className="font-semibold">{symbol}</span>
                    <span className="text-slate-400">×</span>
                    <span className="tabular-nums">{count}</span>
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// Map the raw gender code from the backend to a readable label. Unknown
// (or null) values fall back to "—"; any other non-empty string renders
// as-is so a future backend change (e.g. spelled-out values) still works.
function formatGender(g: string | null | undefined): string {
  if (!g) return "—";
  switch (g) {
    case "M":
      return "Male";
    case "F":
      return "Female";
    case "O":
      return "Other";
    default:
      return g;
  }
}

function Stat({
  label,
  value,
  tone = "neutral",
  className = "",
}: {
  label: string;
  value: string;
  tone?: "neutral" | "success" | "danger";
  className?: string;
}) {
  const valueClass =
    tone === "success"
      ? "text-emerald-700"
      : tone === "danger"
        ? "text-red-700"
        : "text-slate-800";

  return (
    <div
      className={`border border-slate-200 rounded-xl bg-white px-3 py-2.5 ${className}`}
    >
      <div className="text-[10px] uppercase tracking-wide text-slate-400 font-semibold">
        {label}
      </div>
      <div className={`text-sm font-bold tabular-nums mt-0.5 ${valueClass}`}>
        {value}
      </div>
    </div>
  );
}

// 1 → "1st", 2 → "2nd", 11 → "11th", etc.
function ordinal(n: number): string {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
}
